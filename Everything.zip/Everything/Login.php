<?php
require 'dbconnect.php';
$connection = connect_to_db("CAL");
session_start();

$query = "INSERT INTO advocateInformation(name, email, password, bio, image) 
			VALUES(?,?,?,?,?)";

//select id from user table
$query = "SELECT id from advocateInformation where name=?";
$selectUser = $connection -> prepare($query);
$selectUser-> bind_param("s", $name);

//if customer already exists 
mysqli_stmt_execute($selectUser); 
$selectUser -> bind_result($id);
if ($selectUser -> fetch()) {
	echo "Existing customer, your ID is $id <br>";
}

?>

<?php

$dbc = connect_to_db("CAL");
$Query="SELECT name, bio, image FROM advocateInformation"; 
$queryResult=perform_query($dbc, $Query);

while ($row = mysqli_fetch_array($queryResult, MYSQLI_ASSOC)) {
    $nameResult = $row['name'];
    $bioResult = $row['bio'];
    $picResult = $row['image'];
}    

loggedIn = false;

  $Q = "SELECT id, email, password FROM advocateInformation WHERE email == $_POST['email'] AND password = $_POST['password']"; 
  $qResult=perform_query($con, $Q);

  if($qResult != 0) {
    $loggedIn = true;
  }

?>