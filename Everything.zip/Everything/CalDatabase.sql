DROP DATABASE IF EXISTS CAL;

GRANT ALL PRIVILEGES ON CAL.* to elizabeth@localhost IDENTIFIED BY 'riffle';

CREATE DATABASE CAL;

USE CAL;

CREATE TABLE advocateInformation (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,   
  name VARCHAR(256) NOT NULL,
  email VARCHAR(256) NOT NULL,
  password VARCHAR(256) NOT NULL,
  bio VARCHAR(2000) NOT NULL, 
  image LONGBLOB NOT NULL
); 

CREATE TABLE events (
   id  int(11) NOT NULL AUTO_INCREMENT,
   advocateId int,
   title varchar(255) COLLATE utf8_unicode_ci NOT NULL,
   start time NOT NULL,
   client varchar(255) NOT NULL,
   flag varchar(255) NOT NULL,
   date1 date NOT NULL,
   created  datetime NOT NULL,
   modified datetime NOT NULL,
   status  tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=Active, 0=Block',
  PRIMARY KEY (id)
  /*FOREIGN KEY (AdvocateId) REFERENCES advocateInformation(Id)*/
);
