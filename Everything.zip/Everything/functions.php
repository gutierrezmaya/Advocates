<?php

session_start(); 

/*
 * Function requested by Ajax
 */
if(isset($_POST['func']) && !empty($_POST['func'])){
  switch($_POST['func']){
    case 'getCalender':
      getCalender($_POST['year'],$_POST['month']);
      break;
    case 'getEvents':
      getEvents($_POST['date']);
      break;
    //For Add Event
        case 'addEvent':
            addEvent($_POST['date'],$_POST['title'], $_POST['startTime']);
            break;
        case 'addClient':
            addClient($_POST['date'],$_POST['title'], $_POST['id']);
            break;
        case 'deleteEvent':
            deleteEvent($_POST['id']);
            break;
    default:
      break;
  }
}

/*
 * Get calendar full HTML
 */
function getCalender($year = '',$month = '')
{
  $start = strtotime('12:00 AM');
  $dateYear = ($year != '')?$year:date("Y");
  $dateMonth = ($month != '')?$month:date("m");
  $date = $dateYear.'-'.$dateMonth.'-01';
  $currentMonthFirstDay = date("N",strtotime($date));
  $totalDaysOfMonth = cal_days_in_month(CAL_GREGORIAN,$dateMonth,$dateYear);
  $totalDaysOfMonthDisplay = ($currentMonthFirstDay == 7)?($totalDaysOfMonth):($totalDaysOfMonth + $currentMonthFirstDay);
  $boxDisplay = ($totalDaysOfMonthDisplay <= 35)?35:42;
?>

 <script type="text/javascript" src="https://addevent.com/libs/atc/1.6.1/atc.min.js" async defer>
   
 </script>
    <!--Link to stylesheet (External Style Sheet)-->
    <link rel="stylesheet" href="General.css">
    <link rel="stylesheet" href="Modal.css">
  <script src="Home.js" type="text/javascript">
 <?php
 if (isset($_POST["Signup"])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $bio = "Not Available.";
    $image = "Pics/blankProfPic.png";
    mysqli_stmt_execute($insertUser); 
    print_r($con->error);
    $id = mysqli_stmt_insert_id($insertUser);  
    echo "Welcome, Your new ID is $id <br>";
 }
if (isset($_POST["Login"])) {
  $lemail = $_POST['lemail'];
  $lpassword = $_POST['lpassword'];
  $query = "SELECT id FROM advocateInformation WHERE email = '$lemail' AND password = '$lpassword'";
  $result = perform_query($con, $query);
  $rows = mysqli_num_rows($result);
  $_SESSION['advocate'] = FALSE;
  if(mysqli_num_rows($result) == 1) {
    $_SESSION['advocate'] = TRUE;
  } else {
    $_SESSION['advocate'] = FALSE;
    echo "Unable to Login";
  }
  if($_SESSION['advocate']) {
    echo "Welcome! You are now logged in";
  } 
}
?>

</script>

  <!-- login -->
  <div id="mod1" class="modal">
    <form class="modal-content animate" action="Index.php" method="post">
      <div class="imgcontainer">
        <span onclick="document.getElementById('mod1').style.display='none'" class="close" title="Close Modal">&times;</span>
        <img src="Pics/advocateLogo.jpg" id="logoPic" class="avatar"> 
      </div>
      <div class="container">
        <b>Email</b><br>
        <input type="text" placeholder="Enter Email" name="lemail" value="" required><br>
        <b>Password</b><br>
        <input type="password" placeholder="Enter Password" name="lpassword" required>
        <button id="loginbutton" type="submit" name="Login">Login</button>
      </div>
    </form>
  </div>
<!-- sign up --> 
  <div id="mod2" class="modal">
    <form class="modal-content animate" action="Index.php" method="post">
      <div class="imgcontainer">
        <span onclick="document.getElementById('mod2').style.display='none'" class="close" title="Close Modal">&times;</span>
        <img src="Pics/advocateLogo.jpg" id="logoPic" class="avatar"> 
      </div>
      <div class="container">
        <b>Full Name</b><br>
        <input type="text" placeholder="Enter Full Name" name="name" value="" required><br>
        <b>Email</b><br>
        <input type="text" placeholder="Enter Email" name="email" value="" pattern="[A-Za-z0-9._%+-]+@(cmc.edu|students.claremontmckenna.edu)$" title="Must contain a valid CMC email" required><br>
        <b>Password</b><br>
        <input type="password" placeholder="Enter Password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
        <button id="signupbutton" type="submit" name="Signup">Signup</button>
      </div>
    </form>
  </div>

  <script>
// Get the modal
var modal1 = document.getElementById('mod1');
var modal2 = document.getElementById('mod2');
// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal1 || event.target == modal2) {
        modal1.style.display = "none";
        modal2.style.display = "none";
    }
}
</script>

  <header>
    <img src="Pics/advocateLogo.jpg" id="logoPic"> 
    <!-- login and signup buttons -->
    <button id="lbutton" class="button" 
            onclick="document.getElementById('mod1').style.display='block'" style="width:auto; 
          <?php if ($_SESSION['advocate']) {
            echo "display:none";
          } else if (!$_SESSION['advocate']) {
            echo "display:block";
          }?>;">Login</button>
    <button id="sbutton" class="button" 
            onclick="document.getElementById('mod2').style.display='block'" style="width:auto; 
          <?php if ($_SESSION['advocate']) {
              echo "display:none";
          } else if (!$_SESSION['advocate']){
              echo "display:block";
          }?>;">Signup</button>
    <!--logout button, if clicked...-->
    <button id="logout" class="button" onclick="window.location.href='Logout.php'" style="width:auto; 
        <?php if (!$_SESSION['advocate']) {
                echo "display:none";
              } else if ($_SESSION['advocate']){
                echo "display:block";
              }?>;">Log Out</button>
    
    <div class="topnav">
      <a class="active" href="Index.php">Home</a>
      <a href="AboutUs.php">About Us</a>
      <a href="calendar.php">Book an Advocate</a>
      <a href="MeetTheTeam.php">Meet the Team</a>
      <a href="Resources.php">Emergency Resources</a> 
      <?php
          if($_SESSION['advocate']) {
            echo '<a href="EditProfile.php">Edit Profile</a>';
          }
        ?> 
    </div>
  </header>

<h2 style="text-align: center";>Book an Advocate</h2>

  <div id="calender_section">
    <h2>
          <a href="javascript:void(0);" onclick="getCalendar('calendar_div','<?php echo date("Y",strtotime($date.' - 1 Month')); ?>','<?php echo date("m",strtotime($date.' - 1 Month')); ?>');">&lt;&lt;</a>
            <select name="month_dropdown" class="month_dropdown dropdown"><?php echo getAllMonths($dateMonth); ?></select>
      <select name="year_dropdown" class="year_dropdown dropdown"><?php echo getYearList($dateYear); ?></select>
            <a href="javascript:void(0);" onclick="getCalendar('calendar_div','<?php echo date("Y",strtotime($date.' + 1 Month')); ?>','<?php echo date("m",strtotime($date.' + 1 Month')); ?>');">&gt;&gt;</a>
        </h2>
    <div id="event_list" class="none"></div>
     <!--For Add Event-->
        <div id="event_add" class="none">
            <p>Add Office Hours</span></p>
            <p><b>Your Name (Advocate Only): </b><input type="text" id="eventTitle" value=""/></p>

            Start: <select name="time_dropdown" id = "startTime" class="time_dropdown dropdown"><?php getTimesList($start); ?></select>
            <input type="hidden" id="eventDate" value=""/>
            <input type="button" id="addEventBtn" value="Add"/>

        </div>
        <div id="client_add" class="none">
           <p>Sign up to meet with <span id="eventTitleView"></span> for an hour at <span id="eventStart"></span></p>
            <p><b>Your Name: </b><input type="text" id="clientTitle" value=""/></p>
            <div title="Add to Calendar" class="addeventatc" input type ="button" id= "addClientBtn" data-direct = "google" >
      Sign Up & Add to Google Calender
      <div id ="spanHolder"></div>
</div>
            <?php
              if($_SESSION['advocate']) {
                echo $_SESSION['id'];
                echo '<input type="button" id="deleteEventBtn" value="Delete Office Hours"/>';
              }
            ?>
            <input type="hidden" id="clientDate" value=""/>
            <input type="hidden" id="eventId" value=""/>
        </div>
    <div id="calender_section_top">
      <ul>
        <li>Sun</li>
        <li>Mon</li>
        <li>Tue</li>
        <li>Wed</li>
        <li>Thu</li>
        <li>Fri</li>
        <li>Sat</li>
      </ul>
    </div>
    <div id="calender_section_bot">
      <ul>
      <?php
        $dayCount = 1;
        for($cb=1;$cb<=$boxDisplay;$cb++){
          if(($cb >= $currentMonthFirstDay+1 || $currentMonthFirstDay == 7) && $cb <= ($totalDaysOfMonthDisplay)){
            //Current date
            $currentDate = $dateYear.'-'.$dateMonth.'-'.$dayCount;
            $eventNum = 0;
            //Include db configuration file
            include 'dbConfig.php';
            //Get number of events based on the current date
            $result = $db->query("SELECT id, title,client, start FROM Events WHERE date1 = '".$currentDate."' AND status = 1 AND flag != 'x'");
          //  $client= $db->query("SELECT client FROM Events WHERE date1 = '".$currentDate."' AND status = 1");
            //echo $id;

            $eventNum = $result->num_rows;

            //Define date cell color
          //  if ($clientNum > 0){
          //    echo '<li date ="'.$currentDate.'" class = "grey date_cell">';
          //  }
            if(strtotime($currentDate) == strtotime(date("Y-m-d"))){
              echo '<li date="'.$currentDate.'" class="grey date_cell">';
            }else {
              echo '<li date="'.$currentDate.'" class="date_cell">';
            }
            echo '<span>';
            echo $dayCount;
            echo '<br>';
            while ($row = $result->fetch_assoc()) {
              $id = $row['id']; //gets the event id
              $Advocate = $row['title'];
              $start = $row['start'];
              echo '<div class="app">';
              echo '<a href="javascript:;" onclick="addClient(\''.$currentDate.'\', \''.$id.'\', \''.$Advocate.'\', \''.$start.'\');">'.$Advocate.'</a>';
                echo '</div>';

            }
            if($_SESSION['advocate']) {
              echo '<a href="javascript:;" onclick="addEvent(\''.$currentDate.'\');">add event</a>';
            }
            echo '</span>';

            echo '</li>';
            $dayCount++;
      ?>
      <?php }else{ ?>
        <li><span>&nbsp;</span></li>
      <?php } } ?>
      </ul>
    </div>
  </div>

    <script type="text/javascript">
        function getCalendar(target_div,year,month){
            $.ajax({
                type:'POST',
                url:'functions.php',
                data:'func=getCalender&year='+year+'&month='+month,
                success:function(html){
                    $('#'+target_div).html(html);
                }
            });
        }


                  //For Add Client
         function addClient(date, id, advocate, start){
            var spanHolder = '<span class="start">' + date + ' ' + start +'</span>'; 
            spanHolder += '<span class="timezone"> America/Los_Angeles </span>';
            spanHolder += '<span class="title"> Office Hours</span>';
            spanHolder += '<span class="description"> Meet with Advocate ' + advocate + '</span>';
            spanHolder += '<span class="location">CARE center</span>';

            $("#spanHolder").html(spanHolder);
            $('#clientDate').val(date);
            $('#eventId').val(id);
            $('#eventTitleView').html(advocate);
            $('#eventStart').html(start);
            $('#client_list').slideUp('slow');
            $('#client_add').slideDown('slow');
         }

          //For Add Client
        $(document).ready(function(){
            $('#addClientBtn').on('click',function(){
                var date = $('#clientDate').val();
                var title = $('#clientTitle').val();
                var id = $('#eventId').val();
               $.ajax({
                  type:'POST',
                  url:'functions.php',
                  data:'func=addClient&date='+date+'&title='+title+'&id='+id,
                   success:function(msg){
                        if(msg == 'ok'){
                           var dateSplit = date.split("-");
                           $('#clientTitle').val('');
                           alert('Client Added Successfully.');
                           getCalendar('calendar_div',dateSplit[0],dateSplit[1]);
                      }else{
                           alert('Some problem occurred, please try again.');
                       }
                     }
             });
            });
         });


         //For delete event
        $(document).ready(function(){
            $('#deleteEventBtn').on('click',function(){
                var id = $('#eventId').val();
               $.ajax({
                  type:'POST',
                  url:'functions.php',
                  data:'func=deleteEvent&id='+id,
                   success:function(msg){
                        console.log(msg);
                        if(msg == 'ok'){
                           alert('Event Deleted Successfully.');
                           getCalendar('calendar_div',dateSplit[0],dateSplit[1]);
                      }else{
                           alert('Some problem occurred, please try again.');
                       }
                     }
             });
            });
         });


          //For Add Event
         function addEvent(date){
            $('#eventDate').val(date);
            $('#eventDateView').html(date);
            $('#event_list').slideUp('slow');
            $('#event_add').slideDown('slow');
         }

          //For Add Event
        $(document).ready(function(){
            $('#addEventBtn').on('click',function(){
                var date = $('#eventDate').val();
                var title = $('#eventTitle').val();
                var startTime = $('#startTime').val();
               $.ajax({
                  type:'POST',
                  url:'functions.php',
                  data:'func=addEvent&date='+date+'&title='+title+'&startTime='+startTime,
                   success:function(msg){
                        if(msg == 'ok'){
                           var dateSplit = date.split("-");
                           $('#eventTitle').val('');
                           alert('Event Created Successfully.');
                            getCalendar('calendar_div',dateSplit[0],dateSplit[1]);
                    }else{
                          console.log(msg);
                          alert('Some problem occurred, please try again.');
                       }
                     }
             });
            });
         });


        $(document).ready(function(){
            $('.month_dropdown').on('change',function(){
                getCalendar('calendar_div',$('.year_dropdown').val(),$('.month_dropdown').val());
            });
            $('.year_dropdown').on('change',function(){
                getCalendar('calendar_div',$('.year_dropdown').val(),$('.month_dropdown').val());
            });
            $(document).click(function(){
                $('#event_list').slideUp('slow');
            });
        });
    </script>
<?php
}

/*
 * Get months options list.
 */
function getAllMonths($selected = ''){
    $options = '';
    for($i=1;$i<=12;$i++)
    {
        $value = ($i < 10)?'0'.$i:$i;
        $selectedOpt = ($value == $selected)?'selected':'';
        $options .= '<option value="'.$value.'" '.$selectedOpt.' >'.date("F", mktime(0, 0, 0, $i+1, 0, 0)).'</option>';
    }
    return $options;
}

/*
 * Get years options list.
 */
function getYearList($selected = ''){
    $options = '';
    for($i=2015;$i<=2025;$i++)
    {
        $selectedOpt = ($i == $selected)?'selected':'';
        $options .= '<option value="'.$i.'" '.$selectedOpt.' >'.$i.'</option>';
    }
    return $options;
}


/* get times options list */
 function getTimesList($selected = ''){
   for($hours=0; $hours<24; $hours++) // the interval for hours is '1'
    for($mins=0; $mins<60; $mins+=30) // the interval for mins is '30'
             echo '<option>'.str_pad($hours,2,'0',STR_PAD_LEFT).':'
                        .str_pad($mins,2,'0',STR_PAD_LEFT).'</option>';
 }


/*
 * Add client to date
 */

function addClient($date,$title,$id){
    //Include db configuration file
    include 'dbConfig.php';
    $currentDate = date("Y-m-d H:i:s");
    //Insert the event data into database
    $insert = $db->query("UPDATE Events SET flag = 'x', client = '".$title."' WHERE id = '".$id."'
      ");
      // once you insert event data then remove the option to enter a new client
    if($insert){
        echo 'ok';
    }else{
        echo 'err';
    }
}


/*
 *  Delete Event
 */
function deleteEvent($id){
    include 'dbConfig.php';
    $insert = $db->query("DELETE FROM Events WHERE id = '".$id."'");
    if($insert){
        echo 'ok';
    }else{
        echo 'err';
    }
}

/*
 * Add event to date
 */
function addEvent($date,$title, $startTime){
    //Include db configuration file
    include 'dbConfig.php';
    $currentDate = date("Y-m-d H:i:s");
    //Insert the event data into database
    $insert = $db->query("INSERT INTO Events (title,date1,created,modified, start) VALUES ('".$title."','".$date."','".$currentDate."','".$currentDate."', '".$startTime."')");

    print_r($db->error);
    if($insert){
        echo 'ok';
    }else{
        echo 'err';
    }
}

/* if client exists for date then remove the event from view */
//
// function remEvent($date,$title){
//   include 'dbConfig.php';
//   $currentDate = date("Y-m-d H:i:s");
//    SELECT client FROM EVENTS WHERE EXISTS (SELECT )
//
//
// }

?>
