DROP DATABASE IF EXISTS CAL;

GRANT ALL PRIVILEGES ON CAL.* to elizabeth@localhost IDENTIFIED BY 'riffle';

CREATE DATABASE CAL;

USE CAL;

CREATE TABLE events (
   id  int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
   title varchar(256) COLLATE utf8_unicode_ci NOT NULL,
   client_name varchar(256) NOT NULL,
   advocate_id INT UNSIGNED NOT NULL,
   FOREIGN KEY (advocate_id) REFERENCES advocateInformation(id)
   date1 date NOT NULL,
   created  datetime NOT NULL,
   modified datetime NOT NULL,
   status  tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=Active, 0=Block'
);

CREATE TABLE advocateInformation (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,   
  firstName varchar(256) NOT NULL,
  lastName varchar(256) NOT NULL,
  email varchar(255) NOT NULL,
  password varchar(255) NOT NULL,
  bio varchar(2000),
  picture LONGBLOB 
);


INSERT INTO EVENTS (id, title, date1, created, modified, status) Values 
(1, 'PHP : Today PHP Event Calendar Class', '2017-04-22', '2017-04-22 06:15:17', '2017-04-22 06:15:17', 1);
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


INSERT INTO ADVOCATEINFORMATION (id, firstName, lastName, email, bio, picture) Values 
(001, 'Kira', 'Weiss', 'kweiss20@cmc.edu', 'My name is Kira and I like coding.', 'carnival1.jpg');






