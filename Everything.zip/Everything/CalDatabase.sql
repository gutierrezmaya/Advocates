DROP DATABASE IF EXISTS CAL;

GRANT ALL PRIVILEGES ON CAL.* to elizabeth@localhost IDENTIFIED BY 'riffle';

CREATE DATABASE CAL;

USE CAL;

CREATE TABLE advocateInformation (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,   
  name VARCHAR(256) NOT NULL,
  email VARCHAR(256) NOT NULL,
  password VARCHAR(256) NOT NULL,
  bio VARCHAR(2000) NOT NULL, 
  image LONGBLOB NOT NULL
); 

CREATE TABLE events (
   id  int(11) NOT NULL AUTO_INCREMENT,
   advocateId int,
   title varchar(255) COLLATE utf8_unicode_ci NOT NULL,
   start time NOT NULL,
   client varchar(255) NOT NULL,
   flag varchar(255) NOT NULL,
   date1 date NOT NULL,
   created  datetime NOT NULL,
   modified datetime NOT NULL,
   status  tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=Active, 0=Block',
  PRIMARY KEY (id)
  /*FOREIGN KEY (AdvocateId) REFERENCES advocateInformation(Id)*/
);

<?php
//dbconn.php has function to create connection
include 'dbConnect.php';
session_start(); 
?>

<!DOCTYPE HTML>
<html>

<head>
    <!--Title-->
    <title>Home Page</title>

    <!--Meta Tags which give information about the site but do not display-->
    <meta name="description" content="Advocates Website">
    <meta name="keywords" content="HTML, CSS, Javascript">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--Link to stylesheet (External Style Sheet)-->
    <link rel="stylesheet" href="General.css">
    <link rel="stylesheet" href="Modal.css">

</head>
<body>

  
  <script src="Home.js" type="text/javascript">
 <?php
 if (isset($_POST["Signup"])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $bio = "Not Available.";
    $image = "Pics/blankProfPic.png";
    mysqli_stmt_execute($insertUser); 
    print_r($con->error);
    $id = mysqli_stmt_insert_id($insertUser);  
    echo "Welcome, Your new ID is $id <br>";
 }
if (isset($_POST["Login"])) {
  $lemail = $_POST['lemail'];
  $lpassword = $_POST['lpassword'];
  $query = "SELECT id FROM advocateInformation WHERE email = '$lemail' AND password = '$lpassword'";
  $result = perform_query($con, $query);
  $rows = mysqli_num_rows($result);
  $_SESSION['advocate'] = FALSE;
  if(mysqli_num_rows($result) == 1) {
    $_SESSION['advocate'] = TRUE;
  } else {
    $_SESSION['advocate'] = FALSE;
    echo "Unable to Login";
  }
  if($_SESSION['advocate']) {
    echo "Welcome! You are now logged in";
  } 
}
?>

</script>

  <!-- login -->
  <div id="mod1" class="modal">
    <form class="modal-content animate" action="Index.php" method="post">
      <div class="imgcontainer">
        <span onclick="document.getElementById('mod1').style.display='none'" class="close" title="Close Modal">&times;</span>
        <img src="Pics/advocateLogo.jpg" id="logoPic" class="avatar"> 
      </div>
      <div class="container">
        <b>Email</b><br>
        <input type="text" placeholder="Enter Email" name="lemail" value="" required><br>
        <b>Password</b><br>
        <input type="password" placeholder="Enter Password" name="lpassword" required>
        <button id="loginbutton" type="submit" name="Login">Login</button>
      </div>
    </form>
  </div>
<!-- sign up --> 
  <div id="mod2" class="modal">
    <form class="modal-content animate" action="Index.php" method="post">
      <div class="imgcontainer">
        <span onclick="document.getElementById('mod2').style.display='none'" class="close" title="Close Modal">&times;</span>
        <img src="Pics/advocateLogo.jpg" id="logoPic" class="avatar"> 
      </div>
      <div class="container">
        <b>Full Name</b><br>
        <input type="text" placeholder="Enter Full Name" name="name" value="" required><br>
        <b>Email</b><br>
        <input type="text" placeholder="Enter Email" name="email" value="" pattern="[A-Za-z0-9._%+-]+@(cmc.edu|students.claremontmckenna.edu)$" title="Must contain a valid CMC email" required><br>
        <b>Password</b><br>
        <input type="password" placeholder="Enter Password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
        <button id="signupbutton" type="submit" name="Signup">Signup</button>
      </div>
    </form>
  </div>

  <script>
// Get the modal
var modal1 = document.getElementById('mod1');
var modal2 = document.getElementById('mod2');
// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal1 || event.target == modal2) {
        modal1.style.display = "none";
        modal2.style.display = "none";
    }
}
</script>

  <header>
    <img src="Pics/advocateLogo.jpg" id="logoPic"> 
    <!-- login and signup buttons -->
    <button id="lbutton" class="button" 
            onclick="document.getElementById('mod1').style.display='block'" style="width:auto; 
          <?php if ($_SESSION['advocate']) {
            echo "display:none";
          } else if (!$_SESSION['advocate']) {
            echo "display:block";
          }?>;">Login</button>
    <button id="sbutton" class="button" 
            onclick="document.getElementById('mod2').style.display='block'" style="width:auto; 
          <?php if ($_SESSION['advocate']) {
              echo "display:none";
          } else if (!$_SESSION['advocate']){
              echo "display:block";
          }?>;">Signup</button>
    <!--logout button, if clicked...-->
    <button id="logout" class="button" onclick="window.location.href='Logout.php'" style="width:auto; 
        <?php if (!$_SESSION['advocate']) {
                echo "display:none";
              } else if ($_SESSION['advocate']){
                echo "display:block";
              }?>;">Log Out</button>
    
    <div class="topnav">
      <a class="active" href="Index.php">Home</a>
      <a href="AboutUs.php">About Us</a>
      <a href="calendar.php">Book an Advocate</a>
      <a href="MeetTheTeam.php">Meet the Team</a>
      <a href="Resources.php">Emergency Resources</a> 
      <?php
          if($_SESSION['advocate']) {
            echo '<a href="EditProfile.php">Edit Profile</a>';
          }
        ?> 
    </div>
  </header>

  </header>

  <!--Link to stylesheet (External Style Sheet)-->
  <link rel="stylesheet" href="Home.css">

  <h2 style="text-align: center;">Edit Profile</h2>

 <?php
        $dbc = connect_to_db("CAL");

        //get logged in user's id
        $loggedInInfo = $_SESSION['loggedInID'];
        $userId = $loggedInInfo[0];

        //query to get name and bio to display 
        $Query="SELECT name, bio FROM advocateInformation WHERE id='". $userId ."'"; 
        $queryResult=perform_query($dbc, $Query);
        $Result = mysqli_fetch_array($queryResult,MYSQLI_ASSOC);
        $name = $Result['name'];
        $bio = $Result['bio'];

        //Update database with new information
        if (isset($_POST["Update"])) {
          $name = $_POST["name"];
          $bio = $_POST["bioBox"];
          $image = addslashes(file_get_contents(["image"]["tmp_name"]));

          //FIX THIS!!!
          $Query1= "UPDATE advocateInformation SET name=$name bio= $bio image= '" . $image . "' WHERE id='" . $userId . "' "; 
          $queryResult=perform_query($dbc, $Query1);
          print_r($dbc->error);

         

         // mysqli_stmt_execute($insertUser); 
          //print_r($con->error);
         // $id = mysqli_stmt_insert_id($insertUser); ]
      }
 ?>

   <form action="EditProfile.php" method="post" enctype="multipart/form-data">

    <b>Select image to upload: </b><br>
    <input type="file" name="image" id="image"><br><br>
      
    <b>Edit Name</b><br>
    <input type="text" name="name" value= '<?php echo $name ?>' style="width: 775px; border: .5px solid black;" required><br><br>

    <b>Edit Bio</b><br>
    <textarea name = "bioBox" rows="5" cols="120" style="padding: 12px 20px; border: .5px solid black;"><?php echo $bio ?></textarea><br>
        
    <button type="submit" name="Update">Update</button>
  </form>

  <script>

            $(document).ready(function(){
              $('#insert').click.function(){

                var image_name = $('#insert').val();

                if(image_name == "") {
                  </script><?php $image = "Pics/blankProfPic.png"; ?><script>
                  return false;
                }
                else {
                  var extension = $('#Image').val().split('.').pop().toLowerCase();

                  if(jQuery.inArray(extension,['gif', 'png', 'jpg', 'jpeg']) == -1) {
                      alert('Invalid Image File');
                      $('#Image').val('');
                      return false;
                  }
                }
              }
            });

  </script> 


  <div class="footer">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" src="https://www.facebook.com/CMCadvocates/">
    <footer>
        <a href="https://www.facebook.com/CMCadvocates/" class="fa fa-facebook"></a>
        <p> Email:
          <a href="cmcadvocates@gmail.com"> cmcadvocates@gmail.com</a></p>
          <p>Phone Number: (909)377-2400</p>
    </footer>
  </div>


</body>

</html>