DROP DATABASE IF EXISTS CAL;

GRANT ALL PRIVILEGES ON CAL.* to elizabeth@localhost IDENTIFIED BY 'riffle';

CREATE DATABASE CAL;

USE CAL;

CREATE TABLE events (
   id  int(11) NOT NULL AUTO_INCREMENT,
   title varchar(255) COLLATE utf8_unicode_ci NOT NULL,
   date1 date NOT NULL,
   created  datetime NOT NULL,
   modified datetime NOT NULL,
   status  tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=Active, 0=Block',
  PRIMARY KEY (id)
);

INSERT INTO EVENTS (id, title, date1, created, modified, status) Values 
(1, 'PHP : Today PHP Event Calendar Class', '2017-04-22', '2017-04-22 06:15:17', '2017-04-22 06:15:17', 1);
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
