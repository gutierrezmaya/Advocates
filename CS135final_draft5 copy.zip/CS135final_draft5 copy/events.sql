DROP DATABASE IF EXISTS CAL;

GRANT ALL PRIVILEGES ON CAL.* to elizabeth@localhost IDENTIFIED BY 'riffle';

CREATE DATABASE CAL;

USE CAL;

CREATE TABLE events (
   id  int(11) NOT NULL AUTO_INCREMENT,
   title varchar(255) COLLATE utf8_unicode_ci NOT NULL,
   start time NOT NULL,
   end1  time NOT NULL,
   client varchar(255) NOT NULL,
   date1 date NOT NULL,
   created  datetime NOT NULL,
   modified datetime NOT NULL,
   status  tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=Active, 0=Block',
  PRIMARY KEY (id)
);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;